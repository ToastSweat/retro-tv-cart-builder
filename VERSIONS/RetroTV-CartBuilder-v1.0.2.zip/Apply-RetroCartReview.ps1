﻿# Retro TV Cart Builder v1 -- apply exported review state and optional replacements
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$CartID,
    [Parameter(Mandatory=$true)][string]$ReviewCsv,
    [string]$SystemRoot = 'F:\[VIDEOS]\Retro TV Cart Builder'
)
$ErrorActionPreference='Stop'

function Get-StableId {
    param([string]$Prefix, [string]$Value)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Value.ToLowerInvariant())
        $hex = [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-','').ToLowerInvariant()
        return "$Prefix-$($hex.Substring(0,12))"
    } finally {
        $sha.Dispose()
    }
}

function Export-Utf8Csv {
    param([Parameter(Mandatory=$true)]$Rows, [Parameter(Mandatory=$true)][string]$Path)
    $parent = Split-Path -Parent $Path
    if ($parent) { [void][IO.Directory]::CreateDirectory($parent) }

    # Windows PowerShell 5.1 has a nasty binder bug around Generic.List[object]
    # combined with @(...). Avoid the array-subexpression operator entirely.
    $buffer = New-Object System.Collections.ArrayList
    foreach ($row in $Rows) {
        [void]$buffer.Add($row)
    }

    if ($buffer.Count -eq 0) {
        Set-Content -LiteralPath $Path -Value $null -Encoding UTF8
    } else {
        $buffer | Export-Csv -LiteralPath $Path -NoTypeInformation -Encoding UTF8
    }
}

function Read-CsvSafe {
    param([string]$Path)
    if (Test-Path -LiteralPath $Path -PathType Leaf) { return @(Import-Csv -LiteralPath $Path) }
    return @()
}

if (-not (Test-Path -LiteralPath $ReviewCsv -PathType Leaf)) { throw "Review CSV not found: $ReviewCsv" }
$stateDir=Join-Path $SystemRoot 'STATE'
$settings=Get-Content -LiteralPath (Join-Path $stateDir 'settings.json') -Raw | ConvertFrom-Json
$registry=@(Import-Csv -LiteralPath $settings.RegistryPath)
$registryById=@{}; foreach($r in $registry){$registryById[$r.AssetID]=$r}
$carts=@(Import-Csv -LiteralPath $settings.CartRegistryPath)
$cart=@($carts|Where-Object{$_.CartID -eq $CartID}|Select-Object -First 1)
if($cart.Count -eq 0){throw "Unknown cart: $CartID"}
$oldRev=[int]$cart[0].CurrentRevision
$oldManifestPath=$cart[0].ManifestPath
$oldManifest=@(Import-Csv -LiteralPath $oldManifestPath)
$review=@(Import-Csv -LiteralPath $ReviewCsv)
$reviewBySlot=@{};foreach($x in $review){$reviewBySlot[$x.SlotID]=$x}

# Apply global source-health discoveries to the registry.
$globalBad=@('BAD_QUALITY','BAD_AUDIO','NEEDS_CLIPPED','DUPLICATE')
$changedRegistry=$false
foreach($x in $review){
    if($globalBad -contains $x.Action){
        $a=$registryById[$x.AssetID]
        if($a){
            $a.SourceStatus=$x.Action
            if($x.Notes){$a.UserNotes=$x.Notes}
            $changedRegistry=$true
        }
    }
}
if($changedRegistry){Export-Utf8Csv $registry $settings.RegistryPath}

$replacementNeeded=@($review | Where-Object {
    $_.Action -eq 'REPLACE_THIS_CART' -or ($globalBad -contains $_.Action) -or $_.Action -in @('WRONG_ERA','WRONG_NETWORK')
})
if($replacementNeeded.Count -eq 0){
    Write-Host "No cart replacements requested. Source-state updates (if any) were saved."
    exit 0
}

$unresolved=@($replacementNeeded | Where-Object {[string]::IsNullOrWhiteSpace($_.ReplacementAssetID)})
if($unresolved.Count -gt 0){
    Write-Host ""
    Write-Host "These slots need a replacement selection before a new revision can be created:" -ForegroundColor Yellow
    $unresolved | Select-Object Position,SlotID,Role,Title,Action | Format-Table -AutoSize
    Write-Host "Re-open the review dashboard, choose Replacement asset for these slots, and export again."
    exit 2
}

$newRev=$oldRev+1
$revName=('r{0:D3}' -f $newRev)
$newRevDir=Join-Path (Join-Path $settings.BuildRoot $CartID) $revName
[void][IO.Directory]::CreateDirectory($newRevDir)
$newManifest=New-Object 'System.Collections.Generic.List[object]'
foreach($m in $oldManifest){
    $x=$reviewBySlot[$m.SlotID]
    if($x -and -not [string]::IsNullOrWhiteSpace($x.ReplacementAssetID)){
        $a=$registryById[$x.ReplacementAssetID]
        if(-not $a){throw "Unknown replacement asset $($x.ReplacementAssetID) for $($m.SlotID)"}
        if($a.SourceStatus -ne 'READY'){throw "Replacement is not READY: $($a.AssetID) $($a.Title)"}
        if($m.Role -eq 'AD' -and ($a.AssetType -ne 'COMMERCIAL' -or $a.Pool -ne $m.Pool)){throw "Replacement for $($m.SlotID) must be a READY commercial from pool $($m.Pool)."}
        if($m.Role -ne 'AD' -and $m.Role -ne 'SHOW' -and ($a.AssetType -ne 'BRANDING' -or $a.Network -ne $m.Network)){throw "Branding replacement for $($m.SlotID) must be on network $($m.Network)."}
        $newManifest.Add([pscustomobject][ordered]@{
            Position=$m.Position;SlotID=$m.SlotID;Role=$m.Role;AssetID=$a.AssetID;AssetType=$a.AssetType;AssetSubtype=$a.Subtype
            Title=$a.Title;Series=$m.Series;Pool=$a.Pool;Network=$a.Network;SourcePath=$a.SourcePath;DurationSeconds=$a.DurationSeconds
            ReusePolicy=$a.ReusePolicy;ReviewStatus='UNREVIEWED'
        })
    }else{
        $newManifest.Add([pscustomobject][ordered]@{
            Position=$m.Position;SlotID=$m.SlotID;Role=$m.Role;AssetID=$m.AssetID;AssetType=$m.AssetType;AssetSubtype=$m.AssetSubtype
            Title=$m.Title;Series=$m.Series;Pool=$m.Pool;Network=$m.Network;SourcePath=$m.SourcePath;DurationSeconds=$m.DurationSeconds
            ReusePolicy=$m.ReusePolicy;ReviewStatus='UNREVIEWED'
        })
    }
}
$newManifestPath=Join-Path $newRevDir 'cart-manifest.csv'
Export-Utf8Csv $newManifest $newManifestPath

# Close old live reservations and create a complete new revision assignment snapshot.
$assignments=@(Read-CsvSafe $settings.AssignmentPath)
$now=[DateTime]::UtcNow.ToString('o')
foreach($a in $assignments){
    if($a.CartID -eq $CartID -and [int]$a.Revision -eq $oldRev -and $a.AssignmentStatus -in @('RESERVED','ACTIVE')){
        $oldSlot=@($oldManifest|Where-Object{$_.SlotID -eq $a.SlotID}|Select-Object -First 1)
        $newSlot=@($newManifest|Where-Object{$_.SlotID -eq $a.SlotID}|Select-Object -First 1)
        if($newSlot.Count -gt 0 -and $newSlot[0].AssetID -eq $a.AssetID){
            $a.AssignmentStatus='SUPERSEDED'
            $a.ReleaseReason="Carried forward to $revName"
        }else{
            $a.AssignmentStatus='RELEASED'
            $rv=$reviewBySlot[$a.SlotID]
            $a.ReleaseReason=$(if($rv){$rv.Action}else{"Replaced in $revName"})
        }
        $a.ReleasedUtc=$now
    }
}
$combined=New-Object 'System.Collections.Generic.List[object]';foreach($a in $assignments){$combined.Add($a)}
foreach($m in $newManifest){
    $combined.Add([pscustomobject][ordered]@{
        AssignmentID=(Get-StableId 'ASG' "$CartID|$newRev|$($m.SlotID)|$($m.AssetID)")
        CartID=$CartID;Revision=$newRev;SlotID=$m.SlotID;AssetID=$m.AssetID;AssignmentStatus='RESERVED';AssignedUtc=$now;ReleasedUtc='';ReleaseReason=''
    })
}
Export-Utf8Csv $combined $settings.AssignmentPath

$newCarts=New-Object 'System.Collections.Generic.List[object]'
foreach($c in $carts){
    if($c.CartID -eq $CartID){
        $newCarts.Add([pscustomobject][ordered]@{
            CartID=$c.CartID;CurrentRevision=$newRev;Status='DRAFT';Network=$c.Network;DisplayName=$c.DisplayName
            CreatedUtc=$c.CreatedUtc;UpdatedUtc=$now;ManifestPath=$newManifestPath
        })
    }else{$newCarts.Add($c)}
}
Export-Utf8Csv $newCarts $settings.CartRegistryPath
Write-Host ""
Write-Host "Created $CartID $revName with requested replacements."
Write-Host "Manifest: $newManifestPath"
Write-Host "Old good unique assets that were removed are RELEASED back to the pool."
Write-Host "Globally bad/duplicate/needs-clipping assets remain excluded by SourceStatus."
Write-Host "Run Build-RetroCartReview.ps1 -CartID $CartID to review the new revision."
