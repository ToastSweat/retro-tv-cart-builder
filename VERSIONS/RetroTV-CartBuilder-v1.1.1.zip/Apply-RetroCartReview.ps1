﻿# Retro TV Cart Builder v1 -- apply exported review state and optional replacements
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$CartID,
    [Parameter(Mandatory=$true)][string]$ReviewCsv,
    [string]$SystemRoot = 'F:\[VIDEOS]\Retro TV Cart Builder',
    [switch]$AutoReplace
)
$ErrorActionPreference='Stop'

function Get-StableId {
    param([string]$Prefix, [string]$Value)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Value.ToLowerInvariant())
        $hex = [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-','').ToLowerInvariant()
        return "$Prefix-$($hex.Substring(0,12))"
    } finally {
        $sha.Dispose()
    }
}

function Export-Utf8Csv {
    param([Parameter(Mandatory=$true)]$Rows, [Parameter(Mandatory=$true)][string]$Path)
    $parent = Split-Path -Parent $Path
    if ($parent) { [void][IO.Directory]::CreateDirectory($parent) }

    # Windows PowerShell 5.1 has a nasty binder bug around Generic.List[object]
    # combined with @(...). Avoid the array-subexpression operator entirely.
    $buffer = New-Object System.Collections.ArrayList
    foreach ($row in $Rows) {
        [void]$buffer.Add($row)
    }

    if ($buffer.Count -eq 0) {
        Set-Content -LiteralPath $Path -Value $null -Encoding UTF8
    } else {
        $buffer | Export-Csv -LiteralPath $Path -NoTypeInformation -Encoding UTF8
    }
}

function Read-CsvSafe {
    param([string]$Path)
    if (Test-Path -LiteralPath $Path -PathType Leaf) { return @(Import-Csv -LiteralPath $Path) }
    return @()
}

if (-not (Test-Path -LiteralPath $ReviewCsv -PathType Leaf)) { throw "Review CSV not found: $ReviewCsv" }
$stateDir=Join-Path $SystemRoot 'STATE'
$settings=Get-Content -LiteralPath (Join-Path $stateDir 'settings.json') -Raw | ConvertFrom-Json
$registry=@(Import-Csv -LiteralPath $settings.RegistryPath)
$registryById=@{}; foreach($r in $registry){$registryById[$r.AssetID]=$r}
$carts=@(Import-Csv -LiteralPath $settings.CartRegistryPath)
$cart=@($carts|Where-Object{$_.CartID -eq $CartID}|Select-Object -First 1)
if($cart.Count -eq 0){throw "Unknown cart: $CartID"}
$oldRev=[int]$cart[0].CurrentRevision
$oldManifestPath=$cart[0].ManifestPath
$oldManifest=@(Import-Csv -LiteralPath $oldManifestPath)
$review=@(Import-Csv -LiteralPath $ReviewCsv)
$reviewBySlot=@{};foreach($x in $review){$reviewBySlot[$x.SlotID]=$x}

$configPath=Join-Path $settings.ConfigDir ($CartID.ToUpperInvariant()+'.json')
$cfg=$null
if(Test-Path -LiteralPath $configPath){$cfg=Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json}

function To-DoubleOrZero($value){
    $d=0.0
    [void][double]::TryParse(([string]$value),[System.Globalization.NumberStyles]::Float,[cultureinfo]::InvariantCulture,[ref]$d)
    return $d
}

# Global source-health findings. NEEDS_CLIPPED remains excluded from automatic pools;
# this cart can still keep it by storing non-destructive trim instructions in the new manifest.
$globalBad=@('BAD_QUALITY','BAD_AUDIO','NEEDS_CLIPPED','DUPLICATE')
$changedRegistry=$false
foreach($x in $review){
    if($globalBad -contains $x.Action){
        $a=$registryById[$x.AssetID]
        if($a){
            $a.SourceStatus=$x.Action
            if($x.Notes){$a.UserNotes=$x.Notes}
            $changedRegistry=$true
        }
    }
}
if($changedRegistry){Export-Utf8Csv $registry $settings.RegistryPath}

# Track currently occupied UNIQUE assets so auto replacement cannot steal something from another cart.
$assignments=@(Read-CsvSafe $settings.AssignmentPath)
$busy=@{}
foreach($a in $assignments){
    if($a.AssignmentStatus -in @('RESERVED','ACTIVE')){
        $busy[$a.AssetID]=$true
    }
}
$chosenThisRevision=@{}

function Is-ReplacementAvailable($asset){
    if(-not $asset){return $false}
    if($asset.SourceStatus -ne 'READY'){return $false}
    if($chosenThisRevision.ContainsKey($asset.AssetID)){return $false}
    if($asset.ReusePolicy -eq 'UNIQUE' -and $busy.ContainsKey($asset.AssetID)){return $false}
    return $true
}
function AssetText($asset){ return (([string]$asset.Title)+' '+([string]$asset.Notes)).ToLowerInvariant() }
function Matches-Keywords($asset,[object[]]$keywords){
    if(-not $keywords){return $false}
    $hay=AssetText $asset
    foreach($k in $keywords){
        if($k -and $hay.Contains(([string]$k).ToLowerInvariant())){return $true}
    }
    return $false
}
$allShowKeywords=@()
if($cfg){
    $allShowKeywords=@($cfg.Episodes|ForEach-Object{$_.BrandingKeywords}|ForEach-Object{$_}|Where-Object{$_}|Sort-Object -Unique)
}
function Is-ShowSpecific($asset){
    if(-not $allShowKeywords -or $allShowKeywords.Count -eq 0){return $false}
    return (Matches-Keywords $asset $allShowKeywords)
}
function Get-EpisodeKeywordsForSeries([string]$series){
    if(-not $cfg -or [string]::IsNullOrWhiteSpace($series)){return @()}
    $ep=@($cfg.Episodes|Where-Object{$_.Series -eq $series}|Select-Object -First 1)
    if($ep.Count -eq 0){return @()}
    return @($ep[0].BrandingKeywords)
}
function Find-AdjacentShow([int]$manifestIndex,[int]$direction){
    $j=$manifestIndex+$direction
    while($j -ge 0 -and $j -lt $oldManifest.Count){
        if($oldManifest[$j].Role -eq 'SHOW'){return $oldManifest[$j]}
        $j += $direction
    }
    return $null
}
function Pick-AutoReplacement($m,[int]$manifestIndex){
    $candidates=@($registry|Where-Object{Is-ReplacementAvailable $_})
    if($m.Role -eq 'AD'){
        $c=@($candidates|Where-Object{$_.AssetType -eq 'COMMERCIAL' -and $_.Pool -eq $m.Pool}|Sort-Object AssetID)
        if($c.Count){return $c[0]}
        return $null
    }
    if($m.Role -eq 'SHOW'){ return $null }

    $base=@($candidates|Where-Object{$_.AssetType -eq 'BRANDING' -and $_.Network -eq $m.Network})
    if($m.Role -eq 'ANCHOR_BRANDING'){
        $c=@($base|Where-Object{$_.Subtype -in @('IDENT','PROMO','INTRO') -and (To-DoubleOrZero $_.DurationSeconds) -ge 20}|Sort-Object AssetID)
        if($c.Count){return $c[0]}
    }
    elseif($m.Role -eq 'STING'){
        $c=@($base|Where-Object{$_.Subtype -in @('IDENT','BUMPER_GENERIC','TRANSITION') -and (To-DoubleOrZero $_.DurationSeconds) -le 15 -and -not (Is-ShowSpecific $_)}|Sort-Object AssetID)
        if($c.Count){return $c[0]}
    }
    elseif($m.Role -eq 'BUMPER_OUT'){
        $prev=Find-AdjacentShow $manifestIndex -1
        $kw=if($prev){Get-EpisodeKeywordsForSeries $prev.Series}else{@()}
        $match=@($base|Where-Object{$_.Subtype -in @('BUMPER_OUT','BUMPER_GENERIC') -and (Matches-Keywords $_ $kw)}|Sort-Object AssetID)
        if($match.Count){return $match[0]}
        $generic=@($base|Where-Object{$_.Subtype -in @('BUMPER_OUT','BUMPER_GENERIC') -and -not (Is-ShowSpecific $_)}|Sort-Object AssetID)
        if($generic.Count){return $generic[0]}
    }
    elseif($m.Role -eq 'BUMPER_IN'){
        $next=Find-AdjacentShow $manifestIndex 1
        $kw=if($next){Get-EpisodeKeywordsForSeries $next.Series}else{@()}
        $match=@($base|Where-Object{$_.Subtype -in @('BUMPER_IN','BUMPER_GENERIC') -and (Matches-Keywords $_ $kw)}|Sort-Object AssetID)
        if($match.Count){return $match[0]}
        $generic=@($base|Where-Object{$_.Subtype -in @('BUMPER_IN','BUMPER_GENERIC') -and -not (Is-ShowSpecific $_)}|Sort-Object AssetID)
        if($generic.Count){return $generic[0]}
    }
    elseif($m.Role -eq 'NEXT'){
        $next=Find-AdjacentShow $manifestIndex 1
        $kw=if($next){Get-EpisodeKeywordsForSeries $next.Series}else{@()}
        $match=@($base|Where-Object{$_.Subtype -eq 'NEXT' -and (Matches-Keywords $_ $kw)}|Sort-Object AssetID)
        if($match.Count){return $match[0]}
    }
    return $null
}

$changeRows=New-Object System.Collections.ArrayList
$unresolved=New-Object System.Collections.ArrayList

for($i=0;$i -lt $oldManifest.Count;$i++){
    $m=$oldManifest[$i]
    $x=$reviewBySlot[$m.SlotID]
    if(-not $x){continue}

    $trimStart=To-DoubleOrZero $x.TrimStart
    $trimEnd=To-DoubleOrZero $x.TrimEnd
    $needsTrim=($trimStart -gt 0 -or $trimEnd -gt 0)

    $replacementReason=$x.Action -in @('REPLACE_THIS_CART','BAD_QUALITY','BAD_AUDIO','DUPLICATE','WRONG_ERA','WRONG_NETWORK')
    if($x.Action -eq 'NEEDS_CLIPPED' -and -not $needsTrim){
        [void]$unresolved.Add([pscustomobject]@{Position=$m.Position;SlotID=$m.SlotID;Role=$m.Role;Title=$m.Title;Problem='NEEDS_CLIPPED but TrimStart/TrimEnd are both 0'})
        continue
    }

    $replacementId=[string]$x.ReplacementAssetID
    if($replacementReason -and [string]::IsNullOrWhiteSpace($replacementId) -and $AutoReplace){
        $pick=Pick-AutoReplacement $m $i
        if($pick){
            $replacementId=$pick.AssetID
            $chosenThisRevision[$pick.AssetID]=$true
            Write-Host ("Auto replacement: {0} {1} -> {2}" -f $m.Position,$m.Title,$pick.Title)
        }
    }
    if($replacementReason -and [string]::IsNullOrWhiteSpace($replacementId)){
        [void]$unresolved.Add([pscustomobject]@{Position=$m.Position;SlotID=$m.SlotID;Role=$m.Role;Title=$m.Title;Problem="$($x.Action) needs a replacement"})
        continue
    }

    if($replacementId -or $needsTrim){
        [void]$changeRows.Add([pscustomobject]@{
            SlotID=$m.SlotID;ReplacementAssetID=$replacementId;TrimStart=$trimStart;TrimEnd=$trimEnd;Action=$x.Action;Notes=$x.Notes
        })
    }
}

if($unresolved.Count -gt 0){
    Write-Host ""
    Write-Host "Review has unresolved changes:" -ForegroundColor Yellow
    $unresolved | Format-Table -AutoSize
    Write-Host ""
    Write-Host "For NEEDS_CLIPPED, enter Trim Start and/or Trim End in the reviewer."
    Write-Host "For replacements, either select one in the reviewer or rerun this command with -AutoReplace."
    exit 2
}

if($changeRows.Count -eq 0){
    Write-Host "No replacements or trims requested. Global source-state updates (if any) were saved."
    exit 0
}

$changeBySlot=@{};foreach($c in $changeRows){$changeBySlot[$c.SlotID]=$c}
$newRev=$oldRev+1
$revName=('r{0:D3}' -f $newRev)
$newRevDir=Join-Path (Join-Path $settings.BuildRoot $CartID) $revName
[void][IO.Directory]::CreateDirectory($newRevDir)
$newManifest=New-Object 'System.Collections.Generic.List[object]'

for($i=0;$i -lt $oldManifest.Count;$i++){
    $m=$oldManifest[$i]
    $c=$changeBySlot[$m.SlotID]

    if($c -and -not [string]::IsNullOrWhiteSpace([string]$c.ReplacementAssetID)){
        $a=$registryById[$c.ReplacementAssetID]
        if(-not $a){throw "Unknown replacement asset $($c.ReplacementAssetID) for $($m.SlotID)"}
        if($a.SourceStatus -ne 'READY'){throw "Replacement is not READY: $($a.AssetID) $($a.Title)"}
        if($m.Role -eq 'AD' -and ($a.AssetType -ne 'COMMERCIAL' -or $a.Pool -ne $m.Pool)){throw "Replacement for $($m.SlotID) must be a READY commercial from pool $($m.Pool)."}
        if($m.Role -ne 'AD' -and $m.Role -ne 'SHOW' -and ($a.AssetType -ne 'BRANDING' -or $a.Network -ne $m.Network)){throw "Branding replacement for $($m.SlotID) must be on network $($m.Network)."}
        $newManifest.Add([pscustomobject][ordered]@{
            Position=$m.Position;SlotID=$m.SlotID;Role=$m.Role;AssetID=$a.AssetID;AssetType=$a.AssetType;AssetSubtype=$a.Subtype
            Title=$a.Title;Series=$m.Series;Pool=$a.Pool;Network=$a.Network;SourcePath=$a.SourcePath;DurationSeconds=$a.DurationSeconds
            ReusePolicy=$a.ReusePolicy;ReviewStatus='UNREVIEWED';TrimStartSeconds=0;TrimEndSeconds=0
        })
    } else {
        $oldTrimStart=To-DoubleOrZero $m.TrimStartSeconds
        $oldTrimEnd=To-DoubleOrZero $m.TrimEndSeconds
        if($c){
            # Review trim is additive to any trim already applied in an earlier revision.
            $oldTrimStart += [double]$c.TrimStart
            $oldTrimEnd += [double]$c.TrimEnd
        }
        $newManifest.Add([pscustomobject][ordered]@{
            Position=$m.Position;SlotID=$m.SlotID;Role=$m.Role;AssetID=$m.AssetID;AssetType=$m.AssetType;AssetSubtype=$m.AssetSubtype
            Title=$m.Title;Series=$m.Series;Pool=$m.Pool;Network=$m.Network;SourcePath=$m.SourcePath;DurationSeconds=$m.DurationSeconds
            ReusePolicy=$m.ReusePolicy;ReviewStatus='UNREVIEWED';TrimStartSeconds=$oldTrimStart;TrimEndSeconds=$oldTrimEnd
        })
    }
}
$newManifestPath=Join-Path $newRevDir 'cart-manifest.csv'
Export-Utf8Csv $newManifest $newManifestPath

# Close old live reservations and create a complete new revision assignment snapshot.
$now=[DateTime]::UtcNow.ToString('o')
foreach($a in $assignments){
    if($a.CartID -eq $CartID -and [int]$a.Revision -eq $oldRev -and $a.AssignmentStatus -in @('RESERVED','ACTIVE')){
        $newSlot=@($newManifest|Where-Object{$_.SlotID -eq $a.SlotID}|Select-Object -First 1)
        if($newSlot.Count -gt 0 -and $newSlot[0].AssetID -eq $a.AssetID){
            $a.AssignmentStatus='SUPERSEDED'
            $a.ReleaseReason="Carried forward to $revName"
        }else{
            $a.AssignmentStatus='RELEASED'
            $rv=$reviewBySlot[$a.SlotID]
            $a.ReleaseReason=$(if($rv){$rv.Action}else{"Replaced in $revName"})
        }
        $a.ReleasedUtc=$now
    }
}
$combined=New-Object 'System.Collections.Generic.List[object]';foreach($a in $assignments){$combined.Add($a)}
foreach($m in $newManifest){
    $combined.Add([pscustomobject][ordered]@{
        AssignmentID=(Get-StableId 'ASG' "$CartID|$newRev|$($m.SlotID)|$($m.AssetID)")
        CartID=$CartID;Revision=$newRev;SlotID=$m.SlotID;AssetID=$m.AssetID;AssignmentStatus='RESERVED';AssignedUtc=$now;ReleasedUtc='';ReleaseReason=''
    })
}
Export-Utf8Csv $combined $settings.AssignmentPath

$newCarts=New-Object 'System.Collections.Generic.List[object]'
foreach($c in $carts){
    if($c.CartID -eq $CartID){
        $newCarts.Add([pscustomobject][ordered]@{
            CartID=$c.CartID;CurrentRevision=$newRev;Status='DRAFT';Network=$c.Network;DisplayName=$c.DisplayName
            CreatedUtc=$c.CreatedUtc;UpdatedUtc=$now;ManifestPath=$newManifestPath
        })
    }else{$newCarts.Add($c)}
}
Export-Utf8Csv $newCarts $settings.CartRegistryPath

$appliedPath=Join-Path $newRevDir 'changes-from-review.csv'
Export-Utf8Csv $changeRows $appliedPath

Write-Host ""
Write-Host "Created $CartID $revName."
Write-Host "Manifest: $newManifestPath"
Write-Host "Changes:  $appliedPath"
Write-Host "Good UNIQUE assets that were replaced are RELEASED back to the pool."
Write-Host "BAD / DUPLICATE / NEEDS_CLIPPED sources remain excluded from future automatic builds."
Write-Host ""
Write-Host "Next:"
Write-Host "  .\Build-RetroCartReview.ps1 -CartID $CartID"
Write-Host "Only changed/retrimmed clips need new proxies; unchanged clips are reused from cache."
