# Retro TV Cart Builder — v1 Design Contract

## Durable identities

- `AssetID`: stable identity of an episode, commercial, or branding source.
- `CartID`: permanent cartridge identity, e.g. `NICK01`.
- `SlotID`: permanent logical slot within a cart, e.g. `NICK01-BREAK-03-AD-02`.
- `Revision`: immutable build history (`r001`, `r002`, ...).

A source being "used" is an assignment, not a permanent property.

## Reuse policy

- Episodes: `UNIQUE`
- Commercials: `UNIQUE`
- Branding: `REUSABLE`, but every use is still logged.

A good unique asset removed from a cart becomes available again.
A globally bad source remains excluded.

## Global source states

`READY`, `UNREVIEWED`, `MAYBE`, `BAD_QUALITY`, `BAD_AUDIO`,
`NEEDS_CLIPPED`, `DUPLICATE`, `EXCLUDED`.

## Review actions

`GOOD`, `REPLACE_THIS_CART`, `BAD_QUALITY`, `BAD_AUDIO`,
`NEEDS_CLIPPED`, `DUPLICATE`, `WRONG_ERA`, `WRONG_NETWORK`.

## Review philosophy

The continuous review movie must contain the proposed broadcast only.
Never add labels/slates between source clips because boundary quality itself is under review.

Labels, boundaries, navigation, flags and replacement controls belong in the HTML reviewer.

## Functional branding roles

Literal archive taxonomy is preserved.
The planner decides how to *use* the asset.

Examples:

- long `IDENT` / `PROMO` -> `ANCHOR_BRANDING`
- short `IDENT` / generic bumper -> `STING`
- `BUMPER_OUT` -> commercial-break exit
- `BUMPER_IN` -> return
- `NEXT` -> upcoming-program transition

This avoids manually relabeling hundreds of short Cartoon Network idents.

## NICK01 v1 recipe

- long Nickelodeon anchor
- 12 preselected episodes in agreed order
- between shows:
  - matched NEXT when available
  - generic BUMPER_OUT
  - 2 unique `KIDS_90S` commercials
  - matched/generic BUMPER_IN
- short station stings after shows 4 and 8
- no mid-episode cuts yet

This recipe is a reference implementation, not a rule every network must follow.
Fox Kids, Cartoon Network, SNICK, etc. can have different profiles based on how their preserved branding actually works.
