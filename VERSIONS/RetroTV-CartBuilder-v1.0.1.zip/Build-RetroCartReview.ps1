﻿# Retro TV Cart Builder v1 -- normalize proxies, make continuous review video and QA dashboard
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$CartID,
    [string]$SystemRoot = 'F:\[VIDEOS]\Retro TV Cart Builder',
    [string]$FFmpeg = 'ffmpeg',
    [string]$FFprobe = 'ffprobe',
    [switch]$ReencodeAll
)
$ErrorActionPreference = 'Stop'

function Get-StableId {
    param([string]$Prefix, [string]$Value)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Value.ToLowerInvariant())
        $hex = [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-','').ToLowerInvariant()
        return "$Prefix-$($hex.Substring(0,12))"
    } finally {
        $sha.Dispose()
    }
}

function Export-Utf8Csv {
    param([Parameter(Mandatory=$true)]$Rows, [Parameter(Mandatory=$true)][string]$Path)
    $parent = Split-Path -Parent $Path
    if ($parent) { [void][IO.Directory]::CreateDirectory($parent) }

    # Windows PowerShell 5.1 can throw "Argument types do not match" when the
    # array-subexpression operator is used directly on Generic.List[object].
    # Force normal pipeline enumeration first so PSCustomObject rows are exported
    # consistently in both Windows PowerShell 5.1 and PowerShell 7+.
    $buffer = @($Rows | ForEach-Object { $_ })

    if ($buffer.Count -eq 0) {
        Set-Content -LiteralPath $Path -Value $null -Encoding UTF8
    } else {
        $buffer | Export-Csv -LiteralPath $Path -NoTypeInformation -Encoding UTF8
    }
}

function Read-CsvSafe {
    param([string]$Path)
    if (Test-Path -LiteralPath $Path -PathType Leaf) { return @(Import-Csv -LiteralPath $Path) }
    return @()
}

foreach ($cmd in @($FFmpeg,$FFprobe)) {
    if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) { throw "$cmd is not on PATH." }
}
$stateDir = Join-Path $SystemRoot 'STATE'
$settings = Get-Content -LiteralPath (Join-Path $stateDir 'settings.json') -Raw | ConvertFrom-Json
$carts = @(Import-Csv -LiteralPath $settings.CartRegistryPath)
$cart = @($carts | Where-Object {$_.CartID -eq $CartID} | Select-Object -First 1)
if ($cart.Count -eq 0) { throw "Unknown cart $CartID. Run New-RetroCartPlan.ps1 first." }
$revision = [int]$cart[0].CurrentRevision
$revDir = Split-Path -Parent $cart[0].ManifestPath
$manifest = @(Import-Csv -LiteralPath $cart[0].ManifestPath)
if ($manifest.Count -eq 0) { throw "Manifest is empty." }

$reviewDir = Join-Path $revDir 'REVIEW'
[void][IO.Directory]::CreateDirectory($reviewDir)
$cacheDir = Join-Path $SystemRoot 'CACHE\review-v1'
[void][IO.Directory]::CreateDirectory($cacheDir)

$profileText = 'review-v1|618x480|30fps|h264-crf20|gop30|aac128|44100-stereo|loudnorm-16|-1.5'
$vf = 'scale=618:480:force_original_aspect_ratio=decrease,pad=618:480:(ow-iw)/2:(oh-ih)/2:black,setsar=1,fps=30'
$af = 'loudnorm=I=-16:TP=-1.5:LRA=11,aresample=44100'

function Get-FileCacheKey([string]$source) {
    $f = Get-Item -LiteralPath $source -ErrorAction Stop
    return Get-StableId 'PX' ("$source|$($f.Length)|$($f.LastWriteTimeUtc.Ticks)|$profileText")
}
function Has-Audio([string]$source) {
    $s = & $FFprobe -v error -select_streams a:0 -show_entries stream=index -of csv=p=0 $source 2>$null
    return -not [string]::IsNullOrWhiteSpace(($s -join ''))
}
function Get-Duration([string]$source) {
    $raw = & $FFprobe -v error -show_entries format=duration -of default=nw=1:nk=1 $source 2>$null
    $d=0.0
    if (-not [double]::TryParse((($raw -join '').Trim()),[System.Globalization.NumberStyles]::Float,[cultureinfo]::InvariantCulture,[ref]$d)) {
        throw "Could not read duration: $source"
    }
    return $d
}

$proxyRows = New-Object 'System.Collections.Generic.List[object]'
$index=0
foreach ($m in $manifest) {
    $index++
    $source = $m.SourcePath
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing source for $($m.SlotID): $source" }
    $cacheKey = Get-FileCacheKey $source
    $proxy = Join-Path $cacheDir ($cacheKey + '.mp4')
    if ($ReencodeAll -and (Test-Path -LiteralPath $proxy)) { Remove-Item -LiteralPath $proxy -Force }

    if (-not (Test-Path -LiteralPath $proxy -PathType Leaf)) {
        Write-Progress -Activity "Normalizing $CartID review proxies" -Status "$index / $($manifest.Count): $($m.Title)" -PercentComplete (($index/[math]::Max(1,$manifest.Count))*100)
        $hasAudio = Has-Audio $source
        if ($hasAudio) {
            $args = @(
                '-hide_banner','-loglevel','error','-nostdin','-y',
                '-i',$source,
                '-map','0:v:0','-map','0:a:0',
                '-vf',$vf,'-af',$af,
                '-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p',
                '-r','30','-g','30','-keyint_min','30','-sc_threshold','0',
                '-c:a','aac','-b:a','128k','-ar','44100','-ac','2',
                '-movflags','+faststart',
                $proxy
            )
        } else {
            $args = @(
                '-hide_banner','-loglevel','error','-nostdin','-y',
                '-i',$source,
                '-f','lavfi','-i','anullsrc=channel_layout=stereo:sample_rate=44100',
                '-map','0:v:0','-map','1:a:0',
                '-vf',$vf,
                '-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p',
                '-r','30','-g','30','-keyint_min','30','-sc_threshold','0',
                '-c:a','aac','-b:a','128k','-ar','44100','-ac','2',
                '-shortest','-movflags','+faststart',
                $proxy
            )
        }
        & $FFmpeg @args
        if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $proxy)) { throw "FFmpeg failed on $source" }
    }

    $duration = Get-Duration $proxy
    $proxyRows.Add([pscustomobject]@{Manifest=$m;ProxyPath=$proxy;Duration=$duration})
}
Write-Progress -Activity "Normalizing $CartID review proxies" -Completed

# Build the end-to-end review movie from identical cached proxy encodes.
$concatPath = Join-Path $reviewDir 'concat.txt'
$concatLines = @()
foreach ($p in $proxyRows) {
    $safe = $p.ProxyPath.Replace("'","''")
    $concatLines += "file '$safe'"
}
Set-Content -LiteralPath $concatPath -Value $concatLines -Encoding ASCII
$reviewVideo = Join-Path $reviewDir ($CartID + '-review.mp4')
& $FFmpeg -hide_banner -loglevel error -nostdin -y -f concat -safe 0 -i $concatPath -c copy -movflags +faststart $reviewVideo
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $reviewVideo)) { throw "Could not concatenate review video." }

# Exact timeline based on normalized proxy durations.
$timeline = New-Object 'System.Collections.Generic.List[object]'
$cursor=0.0
foreach ($p in $proxyRows) {
    $m=$p.Manifest
    $start=$cursor
    $end=$start+$p.Duration
    $timeline.Add([pscustomobject][ordered]@{
        Position=$m.Position; SlotID=$m.SlotID; Role=$m.Role; AssetID=$m.AssetID; AssetType=$m.AssetType
        AssetSubtype=$m.AssetSubtype; Title=$m.Title; Series=$m.Series; Pool=$m.Pool; Network=$m.Network
        SourcePath=$m.SourcePath; ProxyPath=$p.ProxyPath; DurationSeconds=([math]::Round($p.Duration,3))
        StartSeconds=([math]::Round($start,3)); EndSeconds=([math]::Round($end,3)); ReusePolicy=$m.ReusePolicy
    })
    $cursor=$end
}
$timelineCsv = Join-Path $reviewDir 'review-manifest.csv'
Export-Utf8Csv $timeline $timelineCsv

# Build one global alternatives dataset. JS filters it per slot.
$registry = @(Import-Csv -LiteralPath $settings.RegistryPath)
$assignments = @(Read-CsvSafe $settings.AssignmentPath)
$busy = @{}
foreach ($a in $assignments) {
    if ($a.AssignmentStatus -in @('RESERVED','ACTIVE')) { $busy[$a.AssetID]=$true }
}
$alternatives = @($registry | Where-Object {$_.SourceStatus -eq 'READY'} | ForEach-Object {
    [pscustomobject]@{
        id=$_.AssetID; type=$_.AssetType; subtype=$_.Subtype; title=$_.Title; pool=$_.Pool; network=$_.Network
        duration=$_.DurationSeconds; reuse=$_.ReusePolicy
        available=($_.ReusePolicy -eq 'REUSABLE' -or -not $busy.ContainsKey($_.AssetID))
    }
})

$timelineJson = ConvertTo-Json -InputObject @($timeline | ForEach-Object {
    [pscustomobject]@{
        position=$_.Position; slot=$_.SlotID; role=$_.Role; assetId=$_.AssetID; assetType=$_.AssetType
        subtype=$_.AssetSubtype; title=$_.Title; series=$_.Series; pool=$_.Pool; network=$_.Network
        duration=[double]$_.DurationSeconds; start=[double]$_.StartSeconds; end=[double]$_.EndSeconds
        source=$_.SourcePath; reuse=$_.ReusePolicy
    }
}) -Depth 4 -Compress
$altJson = ConvertTo-Json -InputObject $alternatives -Depth 4 -Compress
$timelineJson = $timelineJson.Replace('<','\u003c')
$altJson = $altJson.Replace('<','\u003c')

$template = @'
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__CART__ __REV__ Review</title>
<style>
:root{color-scheme:dark;--bg:#0d1012;--panel:#171c20;--edge:#334047;--muted:#a9b6bc;--accent:#73d4c5;--warn:#f2c66d;--bad:#ff8d8d}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:#edf3f3;font-family:system-ui,Segoe UI,Arial,sans-serif}
header{position:sticky;top:0;z-index:20;background:#11171bee;border-bottom:1px solid var(--edge);padding:12px 16px}
h1{margin:0;font-size:20px}header p{margin:4px 0 0;color:var(--muted);font-size:12px}
.layout{display:grid;grid-template-columns:minmax(0,1fr) 390px;gap:14px;padding:14px}
.playerPanel,.side{background:var(--panel);border:1px solid var(--edge);border-radius:10px;padding:12px}
video{width:100%;max-height:55vh;background:#000}
#realTimeline{height:48px;background:#080a0b;border:1px solid var(--edge);position:relative;margin-top:10px;cursor:pointer;overflow:hidden}
.segment{position:absolute;top:0;height:100%;border-right:1px solid #0008;background:#2d4747;overflow:hidden;font-size:9px;padding:3px;white-space:nowrap}
.segment:nth-child(3n+1){background:#3e3b55}.segment:nth-child(3n+2){background:#364b3c}
.segment.active{outline:2px solid var(--accent);z-index:3}.playhead{position:absolute;top:0;bottom:0;width:2px;background:#fff;z-index:9;pointer-events:none}
#clipStrip{display:flex;overflow-x:auto;gap:5px;margin-top:8px;padding-bottom:5px}
.clipChip{min-width:145px;max-width:145px;height:72px;border:1px solid var(--edge);background:#20282d;color:#eee;border-radius:6px;padding:6px;text-align:left;cursor:pointer}
.clipChip.active{border:2px solid var(--accent);background:#27403d}.chipRole{font-size:10px;color:var(--accent)}.chipTitle{font-size:11px;line-height:1.2;margin-top:3px;max-height:31px;overflow:hidden}
.current{margin-top:10px;padding:10px;border:1px solid var(--edge);border-radius:8px}.currentTitle{font-size:16px;font-weight:700}.meta{font-size:12px;color:var(--muted);margin-top:4px;overflow-wrap:anywhere}
.buttons{display:flex;flex-wrap:wrap;gap:6px;margin-top:9px}button,select,input,textarea{background:#21292e;color:#edf3f3;border:1px solid #53636b;border-radius:5px;padding:7px;font:inherit;font-size:12px}button{cursor:pointer}button:hover{border-color:var(--accent)}
.side{max-height:calc(100vh - 28px);overflow:auto;position:sticky;top:80px}.side h2{font-size:16px;margin:0 0 8px}
.field{margin:8px 0}.field label{display:block;font-size:11px;color:var(--muted);margin-bottom:3px}.field select,.field input,.field textarea{width:100%}
#clipList{margin-top:12px}.listItem{padding:7px;border-top:1px solid #29343a;cursor:pointer;font-size:11px}.listItem.active{background:#253b39}.listItem .r{color:var(--accent);font-weight:700}
.flagged{color:var(--warn)}.bad{color:var(--bad)}
.toolbar{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
@media(max-width:1050px){.layout{grid-template-columns:1fr}.side{position:static;max-height:none}}
</style>
</head>
<body>
<header><h1>__CART__ · __REV__ Review</h1><p>Continuous proposed broadcast. No title slates are inserted. Scrub freely; the page tracks the exact clip under the playhead.</p></header>
<div class="layout">
<section class="playerPanel">
<video id="video" controls preload="metadata" src="__VIDEO__"></video>
<div id="realTimeline"><div id="playhead" class="playhead"></div></div>
<div id="clipStrip"></div>
<div class="current">
<div class="currentTitle" id="currentTitle"></div>
<div class="meta" id="currentMeta"></div>
<div class="buttons">
<button id="goStart">START</button><button id="goEnd">END</button>
<button id="boundaryIn">BOUNDARY IN</button><button id="boundaryOut">BOUNDARY OUT</button>
<button id="loopIn">LOOP IN</button><button id="loopOut">LOOP OUT</button><button id="stopLoop">STOP LOOP</button>
</div>
</div>
</section>
<aside class="side">
<h2>Review selected clip</h2>
<div class="field"><label>Action / quality state</label><select id="action">
<option>UNREVIEWED</option><option>GOOD</option><option>REPLACE_THIS_CART</option>
<option>BAD_QUALITY</option><option>BAD_AUDIO</option><option>NEEDS_CLIPPED</option>
<option>DUPLICATE</option><option>WRONG_ERA</option><option>WRONG_NETWORK</option>
</select></div>
<div class="field"><label>Replacement asset (optional; filtered to compatible available assets)</label><select id="replacement"><option value="">— none —</option></select></div>
<div class="field"><label>Trim start seconds (non-destructive)</label><input id="trimStart" type="number" min="0" step="0.01" value="0"></div>
<div class="field"><label>Trim end seconds (remove from end)</label><input id="trimEnd" type="number" min="0" step="0.01" value="0"></div>
<div class="field"><label>Notes</label><textarea id="notes" rows="3"></textarea></div>
<div class="toolbar"><button id="exportBtn">Export Review CSV</button><button id="importBtn">Import Review CSV</button><input id="importFile" type="file" accept=".csv" hidden></div>
<div class="meta" id="reviewStats"></div>
<div id="clipList"></div>
</aside>
</div>
<script>
'use strict';
const ITEMS=__TIMELINE__;
const ASSETS=__ALTS__;
const CART="__CART__", REV="__REV__", KEY=`retro-cart-review-${CART}-${REV}`;
const video=document.getElementById('video'), timeline=document.getElementById('realTimeline'), playhead=document.getElementById('playhead');
const strip=document.getElementById('clipStrip'), list=document.getElementById('clipList');
const action=document.getElementById('action'), replacement=document.getElementById('replacement'), notes=document.getElementById('notes');
const trimStart=document.getElementById('trimStart'), trimEnd=document.getElementById('trimEnd');
let selected=0, loop=null, state={}; try{state=JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){state={}}
function st(i){const k=ITEMS[i].slot; if(!state[k])state[k]={action:'UNREVIEWED',notes:'',trimStart:'0',trimEnd:'0',replacement:''}; return state[k]}
function save(){localStorage.setItem(KEY,JSON.stringify(state)); stats()}
function fmt(s){s=Math.max(0,Number(s)||0);const h=Math.floor(s/3600),m=Math.floor((s%3600)/60),x=(s%60).toFixed(1).padStart(4,'0');return h?`${h}:${String(m).padStart(2,'0')}:${x}`:`${m}:${x}`}
function currentIndex(t){let lo=0,hi=ITEMS.length-1;while(lo<=hi){const m=(lo+hi)>>1;if(t<ITEMS[m].start)hi=m-1;else if(t>=ITEMS[m].end)lo=m+1;else return m}return Math.max(0,Math.min(ITEMS.length-1,lo))}
function compatible(item,a){
 if(!a.available||a.id===item.assetId)return false;
 if(item.role==='AD')return a.type==='COMMERCIAL'&&a.pool===item.pool;
 if(item.role==='SHOW')return false;
 if(a.type!=='BRANDING'||a.network!==item.network)return false;
 if(item.role==='ANCHOR_BRANDING')return ['IDENT','PROMO','INTRO'].includes(a.subtype)&&Number(a.duration)>=20;
 if(item.role==='STING')return ['IDENT','BUMPER_GENERIC','TRANSITION'].includes(a.subtype)&&Number(a.duration)<=15;
 if(item.role==='BUMPER_OUT')return ['BUMPER_OUT','BUMPER_GENERIC'].includes(a.subtype);
 if(item.role==='BUMPER_IN')return ['BUMPER_IN','BUMPER_GENERIC'].includes(a.subtype);
 if(item.role==='NEXT')return a.subtype==='NEXT';
 return true;
}
function fillReplacement(){
 const item=ITEMS[selected], cur=st(selected);replacement.innerHTML='<option value="">— none —</option>';
 ASSETS.filter(a=>compatible(item,a)).sort((a,b)=>a.title.localeCompare(b.title)).slice(0,150).forEach(a=>{
   const o=document.createElement('option');o.value=a.id;o.textContent=`${a.subtype||a.type} · ${a.title}`;replacement.appendChild(o)
 }); replacement.value=cur.replacement||'';
}
function select(i,seek=false){selected=Math.max(0,Math.min(ITEMS.length-1,i));const item=ITEMS[selected],cur=st(selected);
 document.getElementById('currentTitle').textContent=`${item.position} · ${item.role} · ${item.title}`;
 document.getElementById('currentMeta').textContent=`${fmt(item.start)} → ${fmt(item.end)} · ${fmt(item.duration)} · ${item.slot} · ${item.assetId}`;
 action.value=cur.action;notes.value=cur.notes||'';trimStart.value=cur.trimStart||'0';trimEnd.value=cur.trimEnd||'0';fillReplacement();
 document.querySelectorAll('.clipChip,.listItem,.segment').forEach(e=>e.classList.remove('active'));
 document.querySelectorAll(`[data-i="${selected}"]`).forEach(e=>e.classList.add('active'));
 const chip=strip.querySelector(`[data-i="${selected}"]`);if(chip)chip.scrollIntoView({block:'nearest',inline:'center'});
 if(seek)video.currentTime=item.start;
}
function build(){
 const total=ITEMS[ITEMS.length-1].end;
 ITEMS.forEach((it,i)=>{
   const seg=document.createElement('div');seg.className='segment';seg.dataset.i=i;seg.style.left=`${it.start/total*100}%`;seg.style.width=`${Math.max(.08,it.duration/total*100)}%`;seg.title=`${it.position} ${it.role} — ${it.title}\n${fmt(it.start)}–${fmt(it.end)}`;seg.onclick=e=>{e.stopPropagation();select(i,true)};timeline.appendChild(seg);
   const b=document.createElement('button');b.className='clipChip';b.dataset.i=i;b.innerHTML=`<div class="chipRole">${it.position} · ${it.role}</div><div class="chipTitle"></div>`;b.querySelector('.chipTitle').textContent=it.title;b.onclick=()=>select(i,true);strip.appendChild(b);
   const li=document.createElement('div');li.className='listItem';li.dataset.i=i;li.innerHTML=`<span class="r">${it.position} ${it.role}</span><br><span></span>`;li.querySelector('span:last-child').textContent=it.title;li.onclick=()=>select(i,true);list.appendChild(li);
 });
 timeline.onclick=e=>{const r=timeline.getBoundingClientRect(),p=(e.clientX-r.left)/r.width;video.currentTime=p*total}
 select(0,false);stats()
}
function stats(){let done=0,bad=0;ITEMS.forEach((it,i)=>{const a=st(i).action;if(a!=='UNREVIEWED')done++;if(['BAD_QUALITY','BAD_AUDIO','NEEDS_CLIPPED','DUPLICATE'].includes(a))bad++;
 const el=list.querySelector(`[data-i="${i}"]`);if(el){el.classList.toggle('flagged',a!=='UNREVIEWED'&&a!=='GOOD');el.classList.toggle('bad',['BAD_QUALITY','BAD_AUDIO','NEEDS_CLIPPED','DUPLICATE'].includes(a));}});
 document.getElementById('reviewStats').textContent=`Reviewed ${done}/${ITEMS.length} · source problems ${bad}`;
}
video.addEventListener('timeupdate',()=>{const total=ITEMS[ITEMS.length-1].end;playhead.style.left=`${Math.min(100,video.currentTime/total*100)}%`;const i=currentIndex(video.currentTime);if(i!==selected)select(i,false);
 if(loop&&video.currentTime>=loop.end){video.currentTime=loop.start;video.play().catch(()=>{})}});
action.onchange=()=>{st(selected).action=action.value;save()};notes.onchange=()=>{st(selected).notes=notes.value;save()};
trimStart.onchange=()=>{st(selected).trimStart=trimStart.value;save()};trimEnd.onchange=()=>{st(selected).trimEnd=trimEnd.value;save()};
replacement.onchange=()=>{st(selected).replacement=replacement.value;save()};
function playRange(a,b,doLoop=false){loop=doLoop?{start:Math.max(0,a),end:Math.min(ITEMS[ITEMS.length-1].end,b)}:{start:Math.max(0,a),end:Math.min(ITEMS[ITEMS.length-1].end,b),once:true};video.currentTime=loop.start;video.play().catch(()=>{})}
video.addEventListener('timeupdate',()=>{if(loop&&loop.once&&video.currentTime>=loop.end){video.pause();loop=null}});
document.getElementById('goStart').onclick=()=>{video.currentTime=ITEMS[selected].start};
document.getElementById('goEnd').onclick=()=>{video.currentTime=Math.max(ITEMS[selected].start,ITEMS[selected].end-6)};
document.getElementById('boundaryIn').onclick=()=>playRange(ITEMS[selected].start-4,ITEMS[selected].start+5,false);
document.getElementById('boundaryOut').onclick=()=>playRange(ITEMS[selected].end-5,ITEMS[selected].end+4,false);
document.getElementById('loopIn').onclick=()=>playRange(ITEMS[selected].start-4,ITEMS[selected].start+5,true);
document.getElementById('loopOut').onclick=()=>playRange(ITEMS[selected].end-5,ITEMS[selected].end+4,true);
document.getElementById('stopLoop').onclick=()=>{loop=null};
function csvQ(v){return `"${String(v??'').replace(/"/g,'""')}"`}
document.getElementById('exportBtn').onclick=()=>{
 const hdr=['Position','SlotID','AssetID','Role','Title','Action','Notes','TrimStart','TrimEnd','ReplacementAssetID'];
 const lines=[hdr.map(csvQ).join(',')];ITEMS.forEach((it,i)=>{const s=st(i);lines.push([it.position,it.slot,it.assetId,it.role,it.title,s.action,s.notes,s.trimStart,s.trimEnd,s.replacement].map(csvQ).join(','))});
 const blob=new Blob([lines.join('\r\n')],{type:'text/csv;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`${CART}-${REV}-review-state.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)
};
document.getElementById('importBtn').onclick=()=>document.getElementById('importFile').click();
document.getElementById('importFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;const txt=await f.text();const lines=txt.split(/\r?\n/).filter(Boolean);function parse(s){let a=[],x='',q=false;for(let i=0;i<s.length;i++){let c=s[i];if(c==='"'){if(q&&s[i+1]==='"'){x+='"';i++}else q=!q}else if(c===','&&!q){a.push(x);x=''}else x+=c}a.push(x);return a}const h=parse(lines[0]);for(let n=1;n<lines.length;n++){const v=parse(lines[n]),o={};h.forEach((k,i)=>o[k]=v[i]??'');if(o.SlotID){state[o.SlotID]={action:o.Action||'UNREVIEWED',notes:o.Notes||'',trimStart:o.TrimStart||'0',trimEnd:o.TrimEnd||'0',replacement:o.ReplacementAssetID||''}}}save();select(selected,false)};
build();
</script></body></html>
'@

$revName=('r{0:D3}' -f $revision)
$html=$template.Replace('__CART__',$CartID).Replace('__REV__',$revName).Replace('__VIDEO__',([IO.Path]::GetFileName($reviewVideo))).Replace('__TIMELINE__',$timelineJson).Replace('__ALTS__',$altJson)
$htmlPath=Join-Path $reviewDir 'cart-review.html'
Set-Content -LiteralPath $htmlPath -Value $html -Encoding UTF8

Write-Host ""
Write-Host "Review build complete."
Write-Host "Video:     $reviewVideo"
Write-Host "Dashboard: $htmlPath"
Write-Host "Timeline:  $timelineCsv"
Write-Host "Runtime:   $([TimeSpan]::FromSeconds($cursor).ToString())"
Write-Host ""
Write-Host "Open cart-review.html. The normal video controls and the custom timeline both scrub the exact continuous broadcast."
Write-Host "Use START/END and BOUNDARY controls for fast clipping QA. Export Review CSV when you are done."
